<?php
// Fichier utilisé pour partager du code similaire sur plusieurs pages.
// De ce fait, si l'on doit rajouter par exemple un script ou mettre à jour les infos du footer,
// Nous n'aurons pas besoin de le faire sur toutes les pages, mais juste ce fichier.
?>


    <footer>
        Copyright 2022
    </footer>
</body>
</html>