<?php
$xml=simplexml_load_file("biblio3.xml");
//Lecture du contenu des éléments
foreach($xml->livre as $val)
{
  echo  "<h3>$val->titre de $val->auteur</h3><b> Paru en $val->date  </b> ";
  //Lecture du nom et du contenu des attributs
  foreach($val->attributes() as $att=>$valatt)
  {
    echo "<b> $att  : $valatt </b>";
  }
  echo "<hr />";
}
?>
