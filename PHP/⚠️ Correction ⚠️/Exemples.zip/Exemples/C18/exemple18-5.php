<?php
$xml=simplexml_load_file("biblio3.xml");
//Modification d'un élément et d'un attribut
$xml->livre[0]->titre="La haine de l'Occident ";
$xml->livre[0]->date="2008";
//Affichage des données du fichier
foreach($xml->livre as $cle=>$val)
{
  static $i=1;
  echo ucfirst($cle)," $i : $val->titre de $val->auteur paru en $val->date<hr />";
  $i++;
}
//Enregistrement des modifications
$chxml= $xml->asxml("biblio3a.xml");
if($chxml) echo "Enregistrement réalisé";
?>
