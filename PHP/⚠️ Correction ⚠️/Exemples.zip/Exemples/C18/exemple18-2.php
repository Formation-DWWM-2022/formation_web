<?php
$xml=simplexml_load_file("biblio2.xml");
//Lecture du contenu des éléments
foreach($xml->livre as $cle=>$val)
{
  static $i=1;
  echo ucfirst($cle)," $i : $val->titre de $val->auteur paru en $val->date<hr />";
  $i++;
}
?>
