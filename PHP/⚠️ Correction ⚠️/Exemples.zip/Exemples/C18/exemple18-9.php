<?php
include("exemple15-2.php");//1
$idcom=connex("magasin","myparam");//2
$requete="SELECT * FROM article";//3
$result=mysql_query($requete,$idcom);//4
$chxml="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<magasin>";//5
while($ligne=mysql_fetch_array($result,MYSQL_ASSOC))//6
{
  $chxml.="<article id=\"{$ligne['id_article']}\" categorie=\"{$ligne['categorie']}\">\n";//7
  $chxml.=" <designation>{$ligne['designation']} </designation>\n";//8
  $chxml.=" <prix>{$ligne['prix']} </prix>\n";//9
  $chxml.= "</article>\n";//10
}
$chxml.="</magasin>";//@11@
file_put_contents("article2.xml",$chxml);//@12@
?>
