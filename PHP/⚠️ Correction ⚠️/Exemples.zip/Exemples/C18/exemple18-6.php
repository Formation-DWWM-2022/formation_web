<!DOCTYPE html>
<html lang="fr">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
<title>Bibliographie XML</title>
</head>
<body>
  <form action= "<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="application/x-www-form-urlencoded">
  <fieldset>
  <legend><b>Bibliographie</b></legend>
  <table><tbody>
  <tr>
  <td>Rechercher tous les : </td>
  <td>
  <select name="choix">
  <option value="titre">Titre</option>
  <option value="auteur">Auteur</option>
  <option value="@editeur">Editeur</option>
  </select>
  </td>
  <td>Dans les catégories
  <select name="cat">
  <option value="//ouvrage/livre/"> Ouvrages </option>
  <option value="//musique/disque/"> Musique </option>
  <option value="//">Toutes </option>
  </select>
  <input type="submit" name="envoi" value="OK"/>
  </td>
  </tr>
  </tbody></table>
  </fieldset>
  </form>

<?php
if(isset($_POST['envoi']))
{
  $choix= $_POST['choix'];
  $cat= $_POST['cat'];
  $xml=simplexml_load_file("biblio4.xml");
  $result= $xml->xpath($cat.$choix);
  //Eliminer les doublons
  $result=array_unique($result);
  echo "<h3>Résultats de la recherche</h3>";
  //Affichage sous forme de liste
  echo "<div><ol>";
  foreach($result as $valeur)
  {
    echo "<li><big>$valeur </big></li>";
  }
  echo "</ol></div>";
}
?>

</body>
</html>
