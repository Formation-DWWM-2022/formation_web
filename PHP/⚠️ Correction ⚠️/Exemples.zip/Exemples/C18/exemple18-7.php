<!DOCTYPE html>
<html lang="fr">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
<title>Enregistrement en XML</title>
</head>
<body>
  <form action= "trait.php" method="post" enctype="application/x-www-form-urlencoded">
  <fieldset>
  <legend><b>Saisie de données</b></legend>
  <table><tbody>
  <tr>
    <td>Titre :
     <input type="text" name="titre" />
    </td>
  </tr>
  <tr>
    <td>Auteur :
     <input type="text" name="auteur" />
    </td>
  </tr>
  <tr>
    <td> Date :
     <input type="text" name="date" />
    </td>
  </tr>
  <tr>
  <td>
  <input type="submit" name="envoi" value="OK"/>
  </td>
  </tr>
  </tbody></table>
  </fieldset>
  </form>
</body>
</html>

