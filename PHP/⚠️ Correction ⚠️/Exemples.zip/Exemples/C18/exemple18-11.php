<?php
$xml=simplexml_load_file("biblio3.xml");//1
//Connexion à la base
include_once("exemple15-2.php");//2
$idcom= connex("biblio","myparam");//3
//Lecture du contenu des éléments
$nblivre= count($xml->livre);//4
echo "Nombre de livres : ",$nblivre,"<hr />";
for($i=0;$i<$nblivre;$i++)//5
{
  echo "NB = ",$i;
  $editeur=$xml->livre[$i][@editeur];//6
  $prix=$xml->livre[$i][@prix];//7
  $titre=htmlentities($xml->livre[$i]->titre);//8
  $auteur=htmlentities($xml->livre[$i]->auteur);//9
  $date=$xml->livre[$i]->date;//10
  //Requête SQL
  $requete= "INSERT INTO livre(idlivre,editeur,prix,titre,auteur,date) VALUES('\N','$editeur','$prix','$titre','$auteur','$date')";//@11@
    //Envoi de la requête d'insertion
  $verif=mysql_query($requete,$idcom);//@12@
    if($verif) echo "<br /> $titre de $auteur a été inséré dans la base<hr />";//@13@
}
?>
