<?php
if(isset($_POST['envoi'])&& !empty($_POST['titre'])&& !empty($_POST['auteur'])&& !empty($_POST['date']))
{
  $titre= htmlspecialchars($_POST['titre']);
  $auteur= htmlspecialchars($_POST['auteur']);
  $date= htmlspecialchars($_POST['date']);
  if(!file_exists("biblio3.xml"))
  {
    $chxml= "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n<biblio>\n <livre>\n  <titre>$titre</titre>\n <auteur>$auteur</auteur>\n <date>$date</date>\n </livre>\n</biblio>";
  }
  else
  {
  $xml=simplexml_load_file("biblio3.xml");
  $chxml = $xml->asXML();
  $chxml = str_replace("</biblio>", "", $chxml);
  $chxml.= "<livre>\n <titre>$titre</titre>\n <auteur>$auteur</auteur>\n <date>$date</date>\n</livre>\n</biblio>";
  echo $chxml;
  }
  $verif=file_put_contents("biblio6.xml",$chxml);
}
?>
