<?php 
//************************************************* 
//Définition d'une fonction d'affichage en français 
//************************************************* 
function datefr($njour=0)
{
 $timestamp=time() + $njour*24*3600;
 $semaine = array(" dimanche "," lundi "," mardi "," mercredi "," jeudi ", " vendredi "," samedi ");
 $mois =array(1=>" janvier "," février "," mars "," avril "," mai "," juin ", " juillet "," août "," septembre "," octobre "," novembre "," décembre "); $chdate= $semaine[date('w',$timestamp)] ." ".date('j',$timestamp)." ". $mois[date('n',$timestamp)];
return $chdate;
} 
?>