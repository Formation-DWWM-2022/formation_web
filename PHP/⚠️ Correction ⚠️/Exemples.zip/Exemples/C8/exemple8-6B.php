<?php
include("exemple8-6.php");
echo "Aujourd'hui :",datefr(),"<br />";
echo "Dans 45 jours : ",datefr(45),"<br />"; 
?>