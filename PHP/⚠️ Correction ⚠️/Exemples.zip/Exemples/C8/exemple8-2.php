<?php
//La fonction microtime()
$temps = microtime();
echo "Chaîne microtime = ", $temps,"<br />";
//Lecture du nombre de microsecondes
$microsec= (integer)substr($temps,2,6);
//Lecture du nombre de secondes
$sec = substr($temps,11,10);
echo "À la microseconde près le timestamp est : $sec.$microsec secondes<br />";
echo "Le nombre de microsecondes est : $microsec μs<br />";
echo "Le nombre de secondes est : $sec secondes<br />";
$x=0;
//Boucle pour perdre du temps
for($i=0;$i<200000;$i++)
{$x+=$i;}
//Temps final
$tempsfin=microtime();
$microsecfin = substr($tempsfin,2,6); 
$duree=$microsecfin-$microsec;
$duree=($duree>0) ? ($duree):(1000000+$duree);
echo "Temps d'exécution du script=", $duree," microsecondes"; 
?>