<?php
//******************************
//Avec setlocale() et strftime() 
//******************************
echo "fonction strftime() et setlocale() <br />"; setlocale (LC_ALL, "fr_FR");
echo "Français : Aujourd'hui",strftime(" %A %d %B %Y %H h %M m %S s %Z",time()),"<br />";
echo "Français GMT : Aujourd'hui",gmstrftime(" %A %d %B %Y %H h %M m %S s %Z",time()),"<br />"; 
$lang = $_SERVER["HTTP_ACCEPT_LANGUAGE"]; 
echo "Langue utilisée par le navigateur = ",$lang,"<br />"; setlocale (LC_ALL, $lang);
?>