<?php
echo "À cet instant précis le timestamp est : ", time(),"<br />";
echo "Dans 23 jours le timestamp sera : ", time()+23*24*3600,"<br />";
echo "Il y a 12 jours le timestamp était : ",time()-12*24*3600,"<br />";
echo"Nombre d'heures depuis le 1/1/1970 = ",round(time()/ 3600),"<br />";
echo"Nombre de jours depuis le 1/1/1970 = ",round(time()/3600/ 24),"<br />"; 
?>