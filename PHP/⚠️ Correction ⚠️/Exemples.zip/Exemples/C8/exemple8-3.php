<!DOCTYPE html> 
<html lang="fr">
 <head>
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
  <title>Dates et durées</title> 
 </head>
 <body>
<div>
<?php  
// La fonction mktime()
$timepasse= mktime(12,5,30,5,30,1969);
$timeaujour = time();
$duree = $timeaujour-$timepasse;
echo "Entre le 30/05/1969 à 12h05m30s et maintenant, il s'est écoulé ",$duree," secondes <br />"; 
echo "Soit ",round($duree/3600), " heures <br />";
$timefutur = mktime(12,5,30,12,25,2016);
$noel = $timefutur-$timeaujour;
echo "Plus que ",$noel, "secondes entre maintenant et Noël, soit ",round($noel/3600/24), " jours, Patience ! <br />";
// La fonction gmmktime()
$timepassegmt = gmmktime(12,5,30,5,30,1969);
echo "Timestamp serveur pour le 30/5/1969= ",$timepasse,"<br />";
echo "Timestamp GMT pour le 30/5/1969= ",$timepassegmt,"<br />";
echo "Décalage horaire = ",$timepasse-$timepassegmt," secondes<br />";
?>
  </div>
 </body>
</html>