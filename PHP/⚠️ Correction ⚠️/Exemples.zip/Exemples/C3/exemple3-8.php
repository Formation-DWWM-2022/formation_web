<?php $n=1;
while($n%7!=0)
{
 $n = rand(1,100);
 echo $n,"&nbsp; /";
}?>
