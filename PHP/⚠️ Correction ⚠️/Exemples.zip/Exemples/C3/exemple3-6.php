<?php
for($i=1,$j=9;$i<10,$j>0;$i++,$j--)
//$i varie de 1 à 9 et $j de 9 à 1
{
echo "<span style=\"border-style:double;border-width:3;\"> $i + $j=10</span>"; }
?>