<?php
do
{
 $n = rand(1,100);
 echo $n,"&nbsp; / "; 
}
while($n%7!=0);
?>