<?php
$a=100;$b=0;
try{
	if($b===0)
{throw new Exception("Division par 0",7);}	else{echo "R&#233;sultat de : $a / $b = ",$a/$b;}
}
catch(Exception $except)
{	
 echo "<hr>Message d'erreur :"; echo $except-&gt;getMessage(),"<hr>";
 echo "Nom du fichier :",$except-&gt;getFile(),"<hr>";
 echo "Num&#233;ro de ligne :",$except-&gt;getLine(),"<hr>";
 echo "Code d'erreur :",$except-&gt;getCode(),"<hr>";
 echo "__toString :",$except-&gt;__toString(),"<hr>";
}
finally
{ 
 echo "L'exception a &#233;t&#233; g&#233;r&#233;e, le script continue<hr>";
}
echo "Vraie Fin";
?>