<?php 
define("HOST","localhost"); 
define("USER","root");
define("PASS","root");
define("HOST",8889);
?>