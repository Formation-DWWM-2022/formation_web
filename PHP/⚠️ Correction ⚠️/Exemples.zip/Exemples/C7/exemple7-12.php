<?php
function nom($prenom,$nom)
{
 yield $prenom;
 yield $nom;
 yield from adresse();
 yield from code();
}
function adresse()
{
 yield "Paris"; yield "France";
}
function code()
{
 yield "75006";
}
foreach(nom("Jan","Geelsen") as $coord)
{
 echo $coord," "; 
}
?>