<?php
class Nombre
{
 public $valeur1=22;
 public $valeur2=75;
 }
$varadd = function ($a) { return $this->valeur1 + $a; };
//Appel en créant un objet
echo "Somme = ",$varadd->call(new Nombre,7); //Affiche 29
echo "<br/>";
//Appel avec un objet déja créé
$nb = new Nombre();
echo "Somme = ",$varadd->call($nb,7); //Affiche 29
echo "<br/>";
$nb->valeur1=55;
echo "Somme = ",$varadd->call($nb,7);//Affiche 62
?>