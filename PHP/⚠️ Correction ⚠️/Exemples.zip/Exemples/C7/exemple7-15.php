<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html" />
<title>Variables statiques</title>
</head>
<body>
<form method="post"  action="exemple7-15.php" >
<fieldset>
<legend>Placements</legend>
<p>Indiquez votre CAPITAL :
<input type="text" name="capital" value=""/></p>
<p>Indiquez votre TAUX en %:
<input type="text" name="taux" value=""/></p>
<input type="submit" name="calcul" value="CALCULER"/><br />
</fieldset>
</form>
</body>
</html>

<?php
//Définition de la fonction
function acquis($capital,$taux)
{
	static $acquis=1;
	static $an=1;
        $coeff = 1+$taux/100;
	$acquis *= $coeff;
	echo "<script type=\"text/javascript\" > alert('En $an ans vous aurez ". round($capital*$acquis,2) ." euros') </script>";
	$an++;
	return round($capital*$acquis,2);
}

//Utilisation de la fonction
if(isset($_POST["taux"])&& isset($_POST["capital"])&& is_numeric($_POST["capital"]) && is_numeric($_POST["taux"]))
{
	for($i=1;$i<5;$i++)
	{
	  echo "Au bout de $i ans vous aurez ". acquis($_POST["capital"],$_POST["taux"]). " euros <br />";
	}
}
?>



