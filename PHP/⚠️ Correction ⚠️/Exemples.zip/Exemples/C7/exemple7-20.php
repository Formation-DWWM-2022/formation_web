<?php
function hanoi($nb,$dep,$arr) 
{
 if ($nb==1) echo "Déplacez un disque du piquet $dep vers le piquet $arr <br />";
 else
 {
  $inter=6-$dep-$arr;
  hanoi($nb-1,$dep,$inter);
  echo "Déplacez un disque du piquet $dep vers le piquet $arr <br />"; hanoi($nb-1,$inter,$arr);
 } 
}
hanoi(4,1,2); 
?>