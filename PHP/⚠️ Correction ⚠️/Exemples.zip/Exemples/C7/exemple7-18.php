<?php
test();
//salut(); // Cet appel provoquerait une erreur fatale
$heure=date("H");
// Définition d'une fonction conditionnelle
if($heure<18)
{
 function salut()
 {
  echo "Bonjour : Fonction accessible seulement avant 18h00 <br />";
 }
}
else
{
 function salut() 
 {
  echo "Bonsoir :Fonction accessible seulement après 18h00 <br />";
 } 
}
// Définition d'une fonction ordinaire
function test()
{
 echo "Fonction accessible partout <br />";
 return TRUE; 
}
salut();
?>