<!DOCTYPE html>
<html lang="fr">
 <head>
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" /> <title>Fonction avec une valeur de paramètre par défaut</title> </head>
 <body> 
  <div>
<?php
function ht($prix,$tax=19.6)
{
return "Prix Hors Taxes :". round($prix*(1-$tax/100),2); 
}
$prix=154;
echo "Prix TTC= $prix &euro; ",ht($prix)," &euro;<br />";
echo "Prix TTC= $prix &euro; ",ht($prix,19.6)," &euro;<br />"; 
echo "Prix TTC= $prix &euro; ",ht($prix,5.5)," &euro;<br />"; 
?>
</div>
</body>
</html>