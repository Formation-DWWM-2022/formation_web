<!DOCTYPE html>
<html lang="fr">
 <head>
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" /> 
  <title>Fonctions ne retournant pas de valeur</title>
 </head>
 <body> 
  <div>
<?php
// Fonction sans argument
function ladate() 
{
 echo "<table ><tr><td 
 style=\"background-color:blue;color:yellow;border-width:10px;border-style:groove;bordercolor:FFCC66;font-style:fantasy;font-size:30px\"> ";
 echo "$a ",date("\l\\e d/m/Y \i\l \\e\s\\t H:i:s");
 echo "</td></tr></table><hr />"; 
}
// Fonction avec un argument
function ladate2($a) 
{
 echo "<table><tr><td style=\"background-color:blue;color:yellow;border-width:10px; border-style:groove;border-color:FFCC66;font-style:fantasy;font-size:30px\">";
 echo "$a ",date("\l\\e d/m/Y \i\l \\e\s\\t H:i:s");
 echo "</td></tr></table><hr />";
}
// Appels des fonctions
echo ladate();
echo ladate2("Bonjour");
echo ladate2("Salut");
echo ladate2();//Provoque un avertissement (Warning)
echo @ladate2();//Empêche l'apparition du message d'avertissement 
?>
</div>
</body>
</html>