<?php
function suite($min,$max,$pas)
{
 $total=0;
 for($i=$min;$i<=$max;$i+=$pas)
 {
  yield $i;
  $total+=$i; 
 }
 return $total;
}
echo "Suite : ";
$gener= suite(0,45,5);
foreach($gener as $nb)
{echo $nb, " ";}
echo "<br/> Total = ",$gener->getReturn();
?>