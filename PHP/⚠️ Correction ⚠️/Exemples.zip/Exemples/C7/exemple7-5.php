<!DOCTYPE html>
<html lang="fr">
 <head>
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" /> <title>Nombres complexes</title>
 </head>
 <body>
  <div>
<?php
function modarg($reel,$imag) 
{
// $mod= hypot($reel,$imag);
// ou encore si vous n'avez pas la fonction hypot()du module standard 
$mod =sqrt($reel*$reel + $imag*$imag);
$arg = atan2($imag,$reel);
return array("module"=>$mod,"argument"=>$arg); 
}
// Appels de la fonction
$a= 5;
$b= 8;
$complex= modarg($a,$b);
echo "<b>Nombre complexe $a + $b i:</b><br /> module = ", $complex["module"] , "<br />argument = ",$complex["argument"]," radians<br />";
?>
</div>
</body>
</html>