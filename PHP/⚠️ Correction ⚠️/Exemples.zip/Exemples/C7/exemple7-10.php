<?php
function suite($min,$max,$pas)
{
 for($i=$min;$i<=$max;$i+=$pas) 
 {
  yield $i; 
 }
}
echo "Suite : "; 
foreach(suite(13,50,5)as $nb){echo $nb, " /// ";}
?>