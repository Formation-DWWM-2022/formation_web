<?php
declare(strict_types=1);
?>
<!DOCTYPE html > 
<html> 
 <head> 
  <meta http-equiv="Content-Type" content="text/html;charset=iso-8859-1" /> 
 <title>CALCUL DE PRÊTS</title> 
 </head> 
 <body> 
<?php function mensualite(int $capital,float $tauxann, int $dureeann,bool $assur)
{
// Calcul du taux mensuel décimal 
$tauxmensuel=$tauxann/100/12;
// Calcul de la durée en mois 
$duree=$dureeann*12;
// Calcul de l’assurance soit 0,035 % du capital par mois
$ass=$assur*$capital*0.00035; 
//vaut 0 si $assur vaut 0
// Calcul de la mensualité 
$mens=($capital*$tauxmensuel)/(1-pow((1+$tauxmensuel),-$duree)) + $ass; 
return round($mens,2);
}
$mens = mensualite(100000,5,3,TRUE);
echo "<h3>Pour un prêt de 100 000 € à 5 % l'an sur 3 ans, la mensualité est de ".$mens ." €
assurance comprise</h3>"; 
//******************************************* 
$cap=800000;
$taux=3.5;
$duree=10; 
$mens = mensualite($cap,$taux,$duree,FALSE);
echo "<h3>Pour un prêt de ".$cap," € à ".$taux, " % l'an sur ".$duree." ans, la mensualité est de ".$mens." € sans assurance </h3>";
?> 
</body> 
</html>