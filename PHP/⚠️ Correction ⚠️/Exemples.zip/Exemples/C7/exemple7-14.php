<!DOCTYPE html>
<html lang="fr">
 <head>
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" /> 
  <title>Fonctions utilisant des variables globales</title>
 </head>
 <body>
  <div>
<?php
function message($machin)
{
 global $truc;
 $machin = $GLOBALS['intro']." je suis $truc $machin <br />"; 
 $truc = "zzzzzzzzzzzzzzzzzzzzz !";
 return $machin;
}
$intro= "Ne me cherches pas,";
$truc = " parti ";
echo message(" à Londres");
$intro= "Si tu me cherches,"; 
$truc=" revenu ";
echo message(" de Nantes"); 
echo $truc;
?>
</div>
</body>
</html>