<!DOCTYPE html>
<html lang="fr">
 <head>
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" /> 
  <title>Fonction de lecture de tableaux</title>
 </head> 
 <body> 
  <div>
<?php
// Définition de la fonction
function tabuni($tab,$bord,$lib1,$lib2) 
{
 echo "<table border=\"$bord\" width=\"100%\"><tbody><tr><th>$lib1</th> <th>$lib2 </th></ tr>";
 foreach($tab as $cle=>$valeur) 
 {
  echo "<tr><td>$cle</td> <td>$valeur </td></tr>"; 
 }
 echo "</tbody> </table><br />"; 
}
// Définition des tableaux
$tab1 = array("France"=>"Paris","Allemagne"=>"Berlin","Espagne"=>"Madrid");
$tab2 = array("Poisson"=>"Requin","Cétacé"=>"Dauphin","Oiseau"=>"Aigle"); 
// Appels de la fonction
tabuni($tab1,1,"Pays","Capitale");
tabuni($tab2,6,"Genre","Espèce");
?>
</div>
</body>
</html>