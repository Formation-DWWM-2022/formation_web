<?php
function prod($a,...$tab)
{
 foreach($tab as $nb)
 {
  $a *=$nb;
 }
 echo " Le produit vaut "; 
 return $a;
}
echo "Produit 1",prod(2,3,5,7),"<br/>";//210
echo "Produit 2",prod(4,9,11,15,20),"<br/>";//118800 
$tab1= range(1,10);
echo "Produit 3",prod(...$tab1),"<br/>";//3628800 
$tab2 = array(7,12,15,3,21);
echo "Produit 4",prod(2,...$tab2),"<br/>";//158760 
echo prod(7);// 7 bien sûr!
?>