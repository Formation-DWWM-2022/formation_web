<!DOCTYPE html>
<html lang="fr">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" /> <title>Variables locales et variables globales</title>
</head>
<body>
<div>
<?php 
$externe="dehors";
$interne ="dedans";
function waytu($interne) 
{
 $interne = "Si tu me cherches, je suis ".$interne ." <br />"; 
 $externe = "n'importe quoi !";
return $interne;
}
echo waytu($interne); // Affiche "Si tu me cherches, je suis dedans" 
echo $interne," <br />"; // Affiche "dedans"
echo waytu($externe); // Affiche "Si tu me cherches, je suis dehors" 
echo $externe," <br />"; // Affiche "dehors"
?>
</div>
</body>
</html>