<?php
$dest  = 'php5@funhtml.com';
$objet = 'Test e-mail en HTML';
// Code HTML de l'e-mail
$texte = '<html>
      <head>
       <title>Envoi de mail HTML</title>
      </head>
      <body>
      <h1>La bonne nouvelle du mois</h1>
       <b>Sortie de PHP 7 version finale!</b>
       <img src=http://www.funhtml.com/php5/C12/php.gif />
       <p>Charger un installeur pour une utilisation en local<br />
       <a href=http://www.mamp.info>Le site MAMP pour Mac</a><br />
       <a href=http://www.wampserver.com>Le site Wampserver pour Windows</a>
       </p>
      </body>
     </html>';

     // En-têtes indispensables pour un e-mailen HTML
     $entete  = 'MIME-Version: 1.0' . "\r\n";
     $entete .= 'Content-type: text/html; charset=iso-8859-1' . "\n";

     // En-têtes additionnels
     $entete .= 'From: PHP7 <php5@funhtml.com>' . "\r\n";

     // Envoi de l'e-mail
if (mail($dest,$objet,$texte,$entete))
{
  echo "Le mail a &#233;t&#233; bien envoy&#233;<br> <br>";
}
else 
{
  echo "le mail n'a pas &#233;t&#233; envoy&#233;<br>";
}     
?>