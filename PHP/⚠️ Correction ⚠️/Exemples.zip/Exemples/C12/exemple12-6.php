<!DOCTYPE html>
<html lang="fr">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
<style type="text/css">
td {background-color:yellow;color:blue;font-family: arial, helvetica, sans-serif; font-size: 12pt;font-weight: bold;}
</style>
<title>Votre commande</title>
</head>
<body>
<div><h3>Articles </h3> "HTML 5 et CSS 3" : 29.90 €<br />"PHP 5" : 29.50 €<br />"MySQL" : 19.75 €<br /><br /></div>
<form action="<?= $_SERVER['PHP_SELF'] ?> " method="post"
enctype="application/x-www-form-urlencoded" >
<fieldset>
  <legend>Passez votre commande</legend>

<table border="0" >
  <tr>
    <td>Article</td>
    <td><input type="text" name="article" size="40" maxlength="256" /></td>
  </tr>
  <tr>
    <td>Quantité</td>
    <td><input type="text" name="quantite" size="40" /></td>
  </tr>
  <tr>
    <td>Nom</td>
    <td><input type="text" name="nom" size="40" maxlength="256" /></td>
  </tr>
  <tr>
    <td>Adresse</td>
    <td><input type="text" name="adresse" size="40" maxlength="256" /></td>
  </tr>
  <tr>
    <td>Mail</td>
    <td><input type="text" name="mail" size="40" maxlength="256" /></td>
  </tr>
  <tr >

    <td colspan="2">&nbsp;&nbsp;<input type="submit" name="envoi" value=" Commander " /></td>
  </tr>
</table>
</fieldset>
</form>
<!-- SCRIPT PHP -->
<?php
//$text='';
//Création du tarif des livres
$tarif= array("HTML 5 et CSS 3"=>29.90,"PHP 5"=>29.50,"MySQL"=>19.75);
//Gestion de la commande
if(isset($_POST['article'])&& isset($_POST['quantite']) && isset($_POST['nom']) && isset($_POST['adresse']) && isset($_POST['mail']) )
{
    $article=$_POST['article'];
    $prix= $tarif[$article];
    $objet="Confirmation de commande";
  //Contenu du mail
    $text= "Nous avons bien re&ccedil;u votre commande de : \n";
    $text.="{$_POST['quantite']} livres ";
    $text.= $_POST['article'] . " au prix unitaire de : ". $prix ." euros \n";
    $text.= "Soit un prix total de : ". $prix * $_POST['quantite'] ." euros \n";
    $text.="Adresse de livraison : \n". $_POST['nom']. " \n";
    $text.=$_POST['adresse']. " \n";
    $text .=" Cordialement";
  if(mail($_POST['mail'],$objet,$text))
  {
    echo "<h1>Vous allez recevoir un mail de confirmation </ h1>";
  }
  else
  {
      echo "<h1>Le mail n'a pas été envoyé: recommencez! </h1>";
    }
}
?>
</body>
</html>
