<?php
$tab= array(800,1492, 1515, 1789);
print_r($tab);
echo "<hr />";
// Ajout au début du tableau
$poitiers=732;
$nb=array_unshift($tab,500,$poitiers);
echo "Le tableau \$tab a maintenant $nb éléments <br>"; print_r($tab);
echo "<hr />";
// Ajout à la fin du tableau
$armi=1918;
$newnb=array_push($tab,1870,1914,$armi);
echo "Le tableau \$tab a maintenant $newnb éléments <br>"; 
print_r($tab);
echo "<hr />";
// Suppression du dernier élément
$suppr= array_pop($tab);
echo "Le tableau \$tab a perdu l'élément $suppr <br>"; 
print_r($tab);
echo "<hr />";
// Suppression du premier élément
$suppr= array_shift($tab);
echo "Le tableau \$tab a perdu l'élément $suppr <br>"; 
print_r($tab);
echo "<hr />";
// Suppression de l'élément d'indice 4
unset($tab[4]);
echo "L'élément d'indice 4 a été supprimé <br>"; print_r($tab);                    
?>