<?php
//******************
//TABLEAU INDICÉ
//******************
//Définition du tableau 
$tabind=array("Blanc2","Jaune","rouge","Vert","Bleu","Noir","Blanc10");
$copie= $tabind;
echo "<b>Tableau indicé d'origine</b><br />";
print_r($tabind);
//Fonction sort()
echo "<hr />Tri en ordre ASCII sans sauvegarde des indices<br />"; 
$tabind=$copie;
sort($tabind);
print_r($tabind);
//Fonction rsort()
echo "<hr /> Tri en ordre ASCII inverse sans sauvegarde des indices<br />";
$tabind=$copie;
rsort($tabind);
print_r($tabind);
//Fonction array_reverse()
echo "<hr />Inversion de l'ordre des éléments<br />"; 
$tabind=$copie;
$tabrev=array_reverse($tabind);
print_r($tabrev);
?>