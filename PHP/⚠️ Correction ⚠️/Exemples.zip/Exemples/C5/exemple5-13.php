<!DOCTYPE html> <html lang="fr">
<head>
 <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
 <title>Lecture d\'un tableau multidimensionnel avec foreach()</title>
 </head> 
 <body> 
  <div>
<?php
// Création du tableau
$clients = array(
"client 1"=>array("nom 1"=>"Leparc","ville 1"=>"Paris","age 1"=>"35"),
"client 2"=>array("nom 2"=>"Duroc","ville 2"=>"Vincennes","age 2"=>"22"),
"client 3"=>array("nom 3"=>"Denoël","ville 3"=>"St Cloud","age 3"=>"47"));
// Ajout d'un élément
$clients["client 7"] =array("nom 7"=>"Duval","ville 7"=>"Marseille","age 7"=>"76");
echo "<table border=\"1\" width=\"100%\" ><thead><tr> <th> Client </th><th> Nom </th> <th> Ville </th><th> Age </th></tr></thead><tbody>";
foreach($clients as $cle=>$tab)
{
 echo "<tr><td align=\"center\"><b> $cle </b></td>"; 
 foreach($tab as $key=>$valeur)
 {
  echo "<td> $key : <b> $valeur </b></td>"; 
 }
 echo "</tr>"; }
?>
</tbody>
</table> 
</div>
</body> 
</html>