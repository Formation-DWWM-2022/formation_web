<?php
// Suite de nombres de 1 a 10
$tabnombre= range(1,10);
print_r($tabnombre);
echo "<hr>";
// Suite de lettres de a à z avec une boucle
for($i=97;$i<=122;$i++) 
{ 
$tabalpha[$i-96]=chr($i); 
}
print_r($tabalpha);
echo "<hr>";
//Suite de lettres de A à M avec range() 
$tabalpha2 = range("A","M"); 
print_r($tabalpha2);
?>