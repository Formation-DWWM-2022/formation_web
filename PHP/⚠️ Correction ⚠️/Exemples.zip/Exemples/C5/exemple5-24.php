<?php
//Définition du tableau
$villes=array("Paris","Perpignan","Marseille","Pau","Nantes","Lille");
//Fonction de sélection
function init($ville)
{
 if($ville[0]=="P" || $ville[0]=="p" ) 
 {
  return $ville;
 }
}
//Utilisation de array_filter()
$select=array_filter($villes,"init");
print_r($select); 
?>