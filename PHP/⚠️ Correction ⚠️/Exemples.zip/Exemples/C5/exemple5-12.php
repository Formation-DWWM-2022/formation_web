<?php
//******************************************************* 
//Lecture de tableau indicé sans récupération des indices 
//*******************************************************
$tab=array("Paris","London","Brüssel");
echo "<H3>Lecture des valeurs des éléments </H3>"; foreach($tab as $ville)
{
 echo "<b>$ville</b> <br>";
}
echo"<hr>";
//*******************************************************
//Lecture de tableau indicé avec récupération des indices //*******************************************************
echo "<h3>lecture des indices et des valeurs des éléments </h3>"; 
foreach($tab as $indice=>$ville)
{
 echo "L'élément d'indice <b>$indice</b> a la valeur <b>$ville</b><br>";
}
echo"<hr>";
//********************************************************
//Lecture de tableau associatif avec récupération des clés
//********************************************************
$tab2=array("France"=>"Paris","Great Britain"=>"London","België"=>"Brüssel");
echo "<h3>lecture des clés et des valeurs des éléments</h3>";
foreach($tab2 as $cle=>$ville)
{
 echo "L'élément de clé <b>$cle</b> a la valeur <b>$ville</b> <br>";
}
echo"<hr>";
?>