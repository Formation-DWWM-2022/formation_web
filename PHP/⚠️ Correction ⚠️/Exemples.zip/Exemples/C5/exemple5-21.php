<?php
//Création du tableau de nombres
$tab = range(1,10);
echo "<h4> Tableau initial</h4>";
print_r($tab);
echo "<h4> Mélange en ordre aléatoire</h4>"; 
//Initialisation du générateur de nombres aléatoires 
srand(time());
//Mélange des éléments puis affichage du tableau
shuffle($tab);
print_r($tab);
?>