<?php
//Définition de la fonction produit
function multi($a,$b)
{
 if($a==0) $a=1; 
 return $a*$b;
}
//array_reduce avec deux paramètres
$n=10;
$tabn= range(1,$n);
$prod=array_reduce($tabn, "multi");
echo "<hr />Produit des éléments = factorielle $n = $n! = ",$prod; 
//Définition de la fonction de concaténation
function concat($a,$b)
{
 $a.=$b;
 return $a;
}
// array_reduce avec trois paramètres
$tabch= array("messieurs "," Hulot", " et "," Tati"); $chaine=array_reduce($tabch,"concat","Salut à ");
echo "<hr>Concaténation des éléments : ",$chaine;
?>