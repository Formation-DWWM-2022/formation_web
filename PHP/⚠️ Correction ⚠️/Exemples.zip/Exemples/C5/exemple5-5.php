<?php 
$montab=array("Paris","London","Brüssel"); 
for ($i=0;$i<count($montab);$i++)
{ 
 echo "L'élément $i est $montab[$i]<br />";
}
?>