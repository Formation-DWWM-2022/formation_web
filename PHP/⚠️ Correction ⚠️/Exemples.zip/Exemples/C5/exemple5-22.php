<?php
//TABLEAUX ASSOCIATIFS
$tabass= array("white2"=>"Blanc2","yellow"=>"Jaune","red"=>"rouge","green"=>"Vert","blue"=>"Bleu","black"=>"Noir","white10"=>"Blanc10");
$copieass=$tabass;
echo "<h4>Tableau associatif d'origine</h4>";
print_r($tabass);
echo "<h4>Tri en ordre alpha des valeurs avec sauvegarde des clés</h4>"; 
$tabass=$copieass;
asort($tabass);
print_r($tabass);
echo "<h4>Tri en ordre alpha inverse avec sauvegarde des clés</h4>"; 
$tabass=$copieass;
arsort($tabass);
print_r($tabass);
echo "<h4>Tri en ordre naturel avec sauvegarde des clés</h4>";
$tabass=$copieass;
natsort($tabass);
print_r($tabass);
echo "<h4>Tri en ordre naturel insensible à la casse avec sauvegarde des clés</h4>"; 
$tabass=$copieass;
natcasesort($tabass);
print_r($tabass);
?>