<?php
//list() avec un tableau indicé
$tab=array("Paris","London","Brüssel");
list($x,$y) = $tab;
echo "Les deux premiers éléments sont : $x et $y <hr />";
// list() avec un tableau associatif (ne fonctionne pas)
$tab=array("France"=>"Paris","Great Britain"=>"London","België"=>"Brüssel"); 
list($x,$y) = $tab;
echo "Les deux premiers éléments sont : $x et $y <hr />"; 
//*************************
//Lecture de tableau indicé 
//************************* $tab=array("Paris","London","Brüssel");
while(list($indice,$valeur) = each($tab) ) 
{
 echo "L'élément d'indice <b>$indice</b> a la valeur <b>$valeur</b><br>"; 
 }
 echo"<hr />";
//*****************************
//Lecture de tableau associatif //***************************** $tab=array("France"=>"Paris","Great Britain"=>"London", ➥"België"=>"Brüssel");
while(list($cle,$valeur) = each($tab) )
{
 echo "L'élément de clé <b>$cle</b> a la valeur <b>$valeur</b><br />"; 
}
?>