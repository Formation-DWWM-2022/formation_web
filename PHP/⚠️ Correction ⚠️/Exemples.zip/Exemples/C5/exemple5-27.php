<?php
$tab = array('a'=>"Linux",'b'=>"Apache");
// Création de l'objet ArrayObject
$objtab =new ArrayObject($tab); 
$objtab['c']="WAMP";
$objtab[]="PHP 5";
$objtab->append("MySQL");
$objtab->append("SQLite");
// Création des propriétés 
$objtab->setFlags(ArrayObject::ARRAY_AS_PROPS); 
echo $objtab->a,"<br />";
echo "<hr />";
$objtab->c="WampServer";
echo $objtab->c,"<br />";
$objtab->d="HTML 5";
echo $objtab->d;
echo "<hr />";
// Lecture des éléments
foreach($objtab as $cle=>$val)
{
 echo "$cle : $val<br />"; 
}
echo "<hr />";
// Affichage du nombre d'éléments
echo "Nombre d'éléments = ",$objtab->count(),"<br />";
// Copie dans un tableau array $tab2=$objtab->getArrayCopy();
print_r($tab2);
echo "<hr />";
// Vérification de l'existence d'un élément d'indice ou de clé donné
$val='a';
if($objtab->offsetExists($val))
{echo $objtab['a'],"<br />";}
// Lecture
echo "L'élément de clé '$val' a la valeur :",$objtab->offsetGet($val),"<br />";
echo "<hr />";
// Ajout d'un élément d'indice ou de clé donné 
$objtab->offsetSet(3,'SimpleXML');
$objtab->offsetSet('c','ArrayObject');
print_r($objtab);
echo "<hr />";
// Suppression d'un élément d'indice ou d’une clé donné
$objtab->offsetUnset(3);
print_r($objtab);
?>