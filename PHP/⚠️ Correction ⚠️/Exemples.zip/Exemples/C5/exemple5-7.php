<?php $montab=array("Paris","London","Brüssel"); $i=0;
while(isset($montab[$i]) )
{
 echo "L'élément $i est $montab[$i]<br />";
 $i++; 
}
?>