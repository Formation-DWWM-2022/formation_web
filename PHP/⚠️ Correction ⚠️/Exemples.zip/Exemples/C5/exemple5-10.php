<!DOCTYPE html>
<html lang="fr">
 <head>
 <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" /> 
 <title>Lecture d\'un tableau indicé avec une boucle while</title>
 </head> 
 <body> 
 <div>
<?php
//******************************** //Tableau indicé multidimensionnel //******************************** // Création du tableau
$clients = array(array ("Leparc", "Paris", "35"), array("Duroc", "Vincennes", "22"), array("Denoël","Saint Cloud","47"));
// Ajout d'un élément
$clients[7] = array("Duval","Marseille","76"); 
echo "<table border=\"1\"><tbody>"; while($element=each($clients))
{
 echo "<tr><td> élément <b> $element[0] </b></td>"; while($val=each($element[1]))
 {
  echo "<td><b>",$val[1]," </b></td>"; 
 }
 echo "</tr>"; }
 echo " </tbody> </table> <hr />";
//************************************ //Tableau associatif multidimensionnel //************************************ // Création du tableau
$clients=array( array("client1"=>"Leparc","ville1"=>"Paris","age1"=>"35"),array("client2"=>"Duroc","ville2"=>"Vincennes","age2"=>"22"),array("client3"=>"Denoël","ville3"=>"Saint Cloud","age3"=>"47"));
// Ajout d'un élément
$clients[7] =array("client7"=>"Duval","ville7"=>"Marseille","age7"=>"76");
echo " <table border=\"1\"><tbody> ";
// Lecture des éléments
while($element=each($clients))
{
 echo "<tr><td> élément <b> $element[0] </b></td>"; while($val=each($element[1]))
 {
 echo "<td> clé :<b>",$val[0],"</b></td><td><b>",$val[1]," </b></td>"; }
 echo "</tr>";
 }
echo " </tbody> </table>";                  
 ?>
 </div> 
 </body> 
 </html>