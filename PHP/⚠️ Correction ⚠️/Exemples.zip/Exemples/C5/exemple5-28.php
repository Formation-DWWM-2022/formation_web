<?php
$tab = array('2'=>"linux",'s'=>"11 apache",'c'=>"2 WAMP",'11'=>"PHP5",'x'=>"MySQL",'e'=>"sQLite"); 
// Création de l'objet ArrayObject
$objtab =new ArrayObject($tab);
echo "TRI&nbsp;ASCII des VALEURS <br />";
$objtab->asort();
foreach($objtab as $cle=>$val) 
{
 echo "$cle : $val<br />"; 
}
echo "<hr />";
//**********
echo "TRI&nbsp;NATUREL des VALEURS <br />";
$objtab->natsort();
foreach($objtab as $cle=>$val)
{
 echo "$cle : $val<br />"; 
}
echo "<hr />";
//**********
echo "TRI&nbsp;NATUREL SANS CASSE des VALEURS <br />"; 
$objtab->natcasesort();
foreach($objtab as $cle=>$val)
{
 echo "$cle : $val<br />"; 
}
echo "<hr />"; 
?>