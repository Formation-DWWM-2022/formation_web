<?php
// Fusion de tableaux indicés
echo "Tableaux indicés <br>";     
$tab1= array("Paris","Lyon","Marseille");
$tab2 = array("Nantes","Orléans","Tours","Paris");
$tab = array_merge($tab1,$tab2);
echo "array_merge donne: ";
print_r($tab);
echo "<hr />";
// Fusion de tableaux associatifs
echo "Tableaux associatifs <br>";
$tabass1= array("Paris" => "75","Lyon" =>"69","Marseille" => "13"); 
$tabass2 = array("Nantes" => "44","Orléans" => "45","Tours" => "37","Paris"=>"Capitale");
echo "array_merge donne: ";
$tabass = array_merge($tabass1,$tabass2);
print_r($tabass);
echo "<hr />";
// Fusion
echo "array_merge_recursive donne : ";
$tabass3 =array_merge_recursive($tabass1,$tabass2);
print_r($tabass3);
?>