<?php
//******************************** 
//TRI SUR UN CRITÈRE PERSONNALISÉ 
//******************************** 
// Définition de la fonction de tri 
function long($mot1,$mot2)
{
if(strlen($mot1)==strlen($mot2)) return 0; 
elseif(strlen($mot1)>strlen($mot2)) return -1; 
else return 1;
}
// Tableau à trier
$tab = array('abc'=>"Blanc",'cdef'=>"Outremer",'c'=>"Rouge",'abcdef'=>"Vert",'x'=>"Orange",'ef'=>"Noir");
// Création de l'objet ArrayObject
$objtab =new ArrayObject($tab);
// Utilisation de la fonction de tri
echo "Tableau initial<br />";
print_r($objtab); 
$objtab->uasort('long'); 
echo "<br />Tri selon la longueur des valeurs <br />";
print_r($objtab);
echo "<br />Tri selon la longueur des clés <br />";
$objtab->uksort('long'); 
print_r($objtab);
?>