<?php
//******************
//TABLEAU ASSOCIATIF
$tabass=array("white2"=>"Blanc2","yellow"=>"Jaune","red"=>"rouge","green"=>"Vert","blue"=>"Bleu","black"=>"Noir","white10"=>"Blanc10");
$copieass=$tabass;
echo "<h4>Tableau associatif d'origine</h4>";
print_r($tabass);

echo "<h4>Tri en ordre ASCII des clés</h4>";
$tabass=$copieass;
ksort($tabass);
print_r($tabass);
echo "<h4>Tri en ordre ASCII inverse des clés</h4>";
$tabass=$copieass;
krsort($tabass);
print_r($tabass);
//********************************
//TRI SUR UN CRITÈRE PERSONNALISÉ
//********************************
function long($mot1,$mot2)
{
 if(strlen($mot1)>strlen($mot2)) return -1; 
 elseif(strlen($mot1)<strlen($mot2)) return 1; 
 else return 0;
}
echo "<h4>Tri selon la longueur des clés </h4>";
uksort($tabass,"long");
print_r($tabass);

?>