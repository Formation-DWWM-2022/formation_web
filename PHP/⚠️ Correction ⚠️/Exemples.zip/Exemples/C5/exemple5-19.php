<?php
//******************
//TABLEAU INDICÉ
//******************
// Définition du tableau
$tabind=["Blanc2","Jaune","rouge","Vert","Bleu","Noir","Blanc10","1ZZ","2AA"]; 
$copie= $tabind;
echo "<b>Tableau indicé d'origine</b><br />";
print_r($tabind);
//********************************
echo "<hr />Tri en ordre naturel avec sauvegarde des indices<br />"; 
$tabind=$copie;
natsort($tabind);
print_r($tabind);
//********************************
echo "<hr />Tri en ordre naturel insensible à la casse avec sauvegarde des indices<br />"; $tabind=$copie;
natcasesort($tabind);
print_r($tabind);
foreach ($tabind as $cle=>$val) {
echo "<br />$cle => $val ";
}
?>