<?php
//********************************
//TRI SUR UN CRITÈRE PERSONNALISÉ 
//******************************** 
// Définition de la fonction de tri
function long($mot1,$mot2)
{
if(strlen($mot1)==strlen($mot2)) return 0; elseif(strlen($mot1)>strlen($mot2)) return -1; 
else return 1;
}
// Tableau à trier
$tab=["Blanc","Jaune","rouge","Vert","Orange","Noir","Emeraude"];
// Utilisation de la fonction de tri
echo "Tri selon la longueur des chaînes de caractères<br>"; 
echo "Tableau initial<br />";
print_r($tab);
usort($tab,"long");
echo "<br />Tableau trié selon la longueur décroissante des mots<br />";
print_r($tab);
?>