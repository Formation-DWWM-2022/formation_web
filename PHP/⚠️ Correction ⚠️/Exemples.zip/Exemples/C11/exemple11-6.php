<!DOCTYPE html>
<html lang="fr">
 <head>
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
<title>Choix d'articles </title>
</head>
<body style="background-color: #ffcc00;">
<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" >
<fieldset>
<legend><b>Choisissez votre sujet! </b></legend>

<input type="submit" name="sujet" value="html" />
<input type="submit" name="sujet" value="javascript" />
<input type="submit" name="sujet" value="php" />
<input type="submit" name="sujet" value="asp" />
</fieldset>
</form>

<?php
//AFFICHAGE
if(isset($_POST['sujet']))
{
  $sujet=$_POST['sujet'];
  echo "<h2>Voici l'article sur ",strtoupper($sujet) ,"</h2> ";
 //**********************************************************
 //Lecture du fichier avec readfile()
 //**********************************************************
  echo "<div style=\" background-color:#FFCCFF ; border-width:3px ; border-style:groove; \" >";
  echo " <h4>LECTURE avec readfile()</h4>";
  readfile($sujet.".txt",TRUE);
  echo "</div>";
 //**********************************************************
 //Lecture du fichier avec fpassthru()
 //**********************************************************
  echo "<div style=\" background-color:#FFAACC ; border-width:3px ; border-style:groove; \" >";
  echo " <h4>LECTURE avec fpassthru()</h4>";
  $id_file=fopen($sujet.".txt","r")    ;
  fpassthru($id_file);
  echo "</div>";
 //**********************************************************
 //Lecture du fichier avec file()
 //**********************************************************
  echo "<div style=\" background-color:#00AAFF ; border-width:3px ; border-style:groove; \" >";
  echo " <h4>LECTURE avec file()</h4>";
  $tab =  file($sujet.".txt",1);
  for($i=0;$i< count($tab); $i++)
  {
    echo $tab[$i],"<br>";
  }
  echo "</div>";
}
?>
</body>
</html>
