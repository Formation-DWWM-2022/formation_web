<?php
$file="votes.txt";
$date1= fileatime($file);
echo "Le dernier accès au fichier $file date de : ",date("d/m/Y H:i:s",$date1),"<br>";
$date2= filemtime($file);
echo "La derniere modification du fichier $file date de : ",date("d/m/Y H:i:s",$date2),"<br>";
$date3= filectime($file);
echo "La derniere modification des permissions du fichier $file est : ",date("d/m/Y H:i:s",$date3),"<br>";
//echo realpath("fichiers7.php"),"<br>";
//echo basename("c:\program files\wampserver\www\php5\c11fichiers\fichiers7.php"),"<br>";
//echo basename(".\php5\c11fichiers\fichiers7.php"),"<br>";
//echo filetype("c:\program files\wampserver\www\php5"),"<br>";
echo $_SERVER['HTTP_USER_AGENT'];
?>

