<!DOCTYPE html>
<html lang="fr">
 <head>
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
<title>Lecture de fichiers avec fgets() </title>
</head>
<body>
<?php
$file="noms.txt";
//Première lecture
$id_file=fopen($file,"r");//
$i=1;
echo "<h3>Lecture du fichier \"$file\" ligne par ligne<br /> Affichage brut de chaque ligne</h3> ";
echo "<table border=\"1\"> \n <tbody> \n";
while($ligne=fgets($id_file,100) )//
{
echo "<tr><td>Ligne numéro $i </td> <td><b>$ligne </b></td> </tr>";//
$i++;
}
fclose($id_file);
echo "</tbody></table> ";
//Deuxième lecture
$id_file=fopen($file,"r");
$i=1;
echo "<h3>Lecture du fichier \"$file\" ligne par ligne<br /> Récupération de chaque donnée  </h3> ";
echo "<table border=\"1\">  <tbody>";
echo "<tr><th>Numéro </th> <th>prenom</th> <th>nom</th> <th>date</th> </tr>";
while($ligne=fgets($id_file,100) )
{
$tab=explode (";",$ligne);

$time=intval($tab[2]);
$jour= date("j/n/Y H:i:s",$time);
echo "<tr><td>$i</td> <th>$tab[0]</th> <th>$tab[1]</th> <th>$jour</th> </tr>";
$i++;
}
fclose($id_file);
echo "</tbody></table> ";
?>
</body>
</html>
