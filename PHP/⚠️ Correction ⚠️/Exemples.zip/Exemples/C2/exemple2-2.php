<?php
// D�finition insensible a la casse
define("PI",3.1415926535,TRUE);
// Utilisation
echo "La constante PI vaut ",PI,"<br />"; 
echo "La constante PI vaut ",pi,"<br />"; 
// V�rification de l�existence
if (defined( "PI")) echo "La constante PI est d&#233;ja d&#233;finie","<br />";
if (defined( "pi")) echo "La constante pi est d&#233;ja d&#233;finie","<br />";

// D�finition sensible � la casse, v�rification de l�existence et utilisation 

if(define("site","http://www.funhtml.com",FALSE))
{
 echo "<a href=",site,">Lien vers mon site</a>";
}
?>