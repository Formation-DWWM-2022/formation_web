<?php
$modele="/([[:alpha:]]+) ([^0-9])/";
$nom="Benoit Saez";
if(!preg_match($modele,$nom))
{echo "Le nom \"$nom\" n'est pas conforme. Veuillez le ressaisir !";} 
else echo $nom, " : Bonne saisie";
?>