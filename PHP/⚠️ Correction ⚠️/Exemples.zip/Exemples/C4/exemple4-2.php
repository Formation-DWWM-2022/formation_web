<?php 
for($i=1;$i<6;$i++) 
{
 $nb=rand(65,90);
 $code.=chr($nb);
}
echo "Votre mot de passe est : ",$code;
?>