<?php
$ch="1789 Prise de la Bastille";
$modele= "/([[:digit:]]{4}) (.*)/";
if(preg_match($modele,$ch,$tab))
{
 echo "La chaîne \"$ch\" est conforme au modèle \"$modele\" <br />";
 echo "Date : ",$tab[1],"<br />";
 echo "Événement : ",$tab[2],"<br />";
}
else 
echo "La chaîne \"$ch\" n'est pas conforme au modèle \"$modele\" ";
?>