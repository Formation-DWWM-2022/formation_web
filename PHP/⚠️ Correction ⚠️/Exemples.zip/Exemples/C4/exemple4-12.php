<?php
// Création de la fonction de validation
function validmail($ch)
{
 $modele="/(^[a-z])([a-z0-9])+(\.|-)?([a-z0-9]+)@([a-z0-9]{2,})\.([a-z]{2,4}$)/";
 $ch=strtolower($ch);
 if (preg_match($modele, $ch))
 {
  echo "$ch est valide <br />";
  return TRUE; }
 else
 {
  echo "$ch est invalide <br />";
  return FALSE; }
 }
// Utilisation de la fonction de validation
$mail="Jean5.dupont@laposte2.uk";$mail2="5pierre.dupapi@plusloin.info"; $mail3="engels-jean@funphp.com"; 
validmail($mail);
validmail($mail2); 
validmail($mail3); 
?>