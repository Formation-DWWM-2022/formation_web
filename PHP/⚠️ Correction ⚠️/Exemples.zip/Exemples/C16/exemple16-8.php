<!DOCTYPE html>
<html lang="fr">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
   <title>Modifiez vos coordonnées</title>
</head>
<body>
  <form action= "exemple16-9.php" method="post" enctype="application/x-www-form-urlencoded">
  <fieldset>
  <legend><b>Saisissez votre code client pour modifier vos coordonnées</b></legend>
  <table><tbody>
  <tr>
  <td>Code client : </td>
  <td><input type="text" name="code" size="20" maxlength="10"/></td>
  </tr>
  <tr>
  <td>Modifier : </td>
  <td><input type="submit" value="Modifier"/></td>
  </tr>
  </tbody></table>
  </fieldset>
  </form>
</body>
</html>
