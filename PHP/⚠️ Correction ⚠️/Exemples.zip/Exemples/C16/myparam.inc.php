<?php 
define("HOST","localhost"); 
define("USER","root"); 
define("PASS","root"); 
define("PORT",8889);
?>