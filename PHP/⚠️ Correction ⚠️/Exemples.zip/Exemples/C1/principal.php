<?php
include("tete.inc.php");
echo "<hr />";
include_once("corps.inc.php");
require("corps.html");
require_once("pied.inc.php");
?>