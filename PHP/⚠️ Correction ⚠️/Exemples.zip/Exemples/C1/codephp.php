<!DOCTYPE html> 
<html lang="fr">
 <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <title>Une page PHP</title>
 </head>
 <body>
  <?php
   echo "<h3> Aujourd'hui le ". date('d / M / Y H:m:s')."</h3><hr />"; 
   echo "<h2>Bienvenue sur le site PHP 7</h2>";
  ?> 
 </body>
</html>