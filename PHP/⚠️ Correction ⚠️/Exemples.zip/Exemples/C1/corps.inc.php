<?php
 echo "<h1> Ceci est le corps du document </h1> ";
 echo "<h2> Ceci est le corps du document </h2> ";
?>