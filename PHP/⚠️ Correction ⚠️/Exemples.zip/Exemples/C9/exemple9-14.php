<?php
// Classe parent 
class leparent
{
 public function salut()
 {
  echo "Bonjour à vous!<br />"; 
 }
}
// Trait 
trait djeuns
{
 public function salut()
 {
  echo "Bjr"; 
 }
}
// Classe dérivée
class enfant extends leparent
{
 use djeuns;
 public function salut()
 {
  echo "Salut toi!<br />" ;
  parent::salut();
 }
}
// Objet de la classe dérivée 
$boy= new enfant();
$boy->salut();
?>