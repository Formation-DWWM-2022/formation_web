<?php
class varchar
{
  private $chaine;
  function __construct($a)
  {
    $this->chaine= (string)$a;
  }
  function add($addch)
  {
    $this->chaine.=$addch;
    return $this;
  }
  function getch()
  {
	  return  $this->chaine;
  }
}
//Création d'objet
$texte=new varchar("Apache ");
echo $texte->getch(),"<hr />";
echo $texte->add( " PHP 7 ")->getch(),"<hr />";
echo $texte->add(" MySQL ")->add("SQLite ")->getch(),"<hr />";
?>
