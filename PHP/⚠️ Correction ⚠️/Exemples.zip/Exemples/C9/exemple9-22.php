<?php
namespace Bourse\Obligation;
function date()
{
echo " Fonction date";
}
class Valeur
{
  public $nom;
  public $cours;
  public $taux;

  public function __construct($nom,$valeur,$taux)
  {
    $this->nom=$nom;
    $this->cours=$valeur;
    $this->taux=$taux;
  }

  public function info()
  {
    echo \date('d / m / Y : ');
    echo "L'obligation $this->nom à $this->taux % vaut $this->cours &euro;<br />";
  }
  public function changeCours($val)
  {
    $this->cours=$val;
  }
}
?>
