<?php
class maclasse
{
    private $code ;

    public function __construct($val)
    {
        $this->code = $val;
    }

    public function __set($prop, $val)
    {
        echo "Affectation de la valeur $val à la propriété $prop <br /> ";
        $this->$prop = $val;
    }

    public function __get($prop)
    {
        return $this->$prop;
    }

    public function __isset($prop)
    {
        if(isset($this->$prop)) echo "La propriété $prop est définie <br />";

    else echo "La propriété $prop n'est pas définie <br />";
    }

    public function __unset($prop)
    {
        echo "Effacement de la prop $prop <br />";
        unset($this->$prop);
    }
}
//Création d'un objet
$obj = new maclasse('AZERTY');
echo isset($obj->code);
echo "code = ", $obj->code," <br />";
$obj->code="QWERTY";
echo "code = ", $obj->code," <br />";
echo isset($obj->code);
unset($obj->code);
echo "code = ", $obj->code," <br />";
?>
