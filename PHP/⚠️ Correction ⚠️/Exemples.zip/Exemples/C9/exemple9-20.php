<?php
require 'exemple9-19.php';
//Constante
echo"Une constante : ", MonEspace\Test\MYNAME ,"<hr />";
echo "Appel de la fonction get() de l'espace  MonEspace::Test : ";
echo MonEspace\Test\get();

use MonEspace\Test;
echo"Une constante : ", Test\MYNAME,"<hr />";
echo "Appel de la fonction get() de l'espace  MonEspace\Test : ";
echo Test\get();

//Objet 1
$moi = new MonEspace\Test\Personne("Moi");
//Objet 2
use MonEspace\Test\Personne ;
$toi = new Personne("Elle");
//********Méthode et fonction du namespace
echo "Appel de la méthode get() des objets Personne : <br />";
echo $toi->get(), " et ",$moi->get();
?>
