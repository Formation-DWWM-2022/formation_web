<?php
trait UN
{
 public function small($text)
 {
  echo "<small>trait UN : $text</small>";
 }
 public function big($text)
 {
  echo "<h4>trait UN : $text</h4>";
 }
}

trait DEUX
{
 public function small($text)
 {
  echo "<i>trait DEUX : $text </i>";
 }
 public function big($text)
 {
  echo "<h2>trait DEUX : $text </h2>";
 }
}

class texte
{
 use UN, DEUX
 {
  DEUX::small insteadof UN;
  UN::big insteadof DEUX;
  DEUX::big as gros;
  UN::small as petit;
 }
}
//test des traits
$a=new texte();
$a->small("Méthode small");
$a->big("Méthode big");
$a->gros("Méthode gros");
$a->petit("Méthode petit")
?>
