<?php
namespace Bourse\Action;
class Valeur
{
  public $nom;

  public $cours;

  public function __construct($nom,$valeur)
  {
    $this->nom=$nom;
    $this->cours=$valeur;
  }

  public function info()
  {
    echo date('d / m / Y : ');
    echo "L'action $this->nom vaut $this->cours &euro;<br />";
  }
  public function changeCours($val)
  {
    $this->cours=$val;
  }

}

?>
