<?php 
require('exemple9-5.php');
$client="Geelsen";
$mortendi = new action();
$mortendi->nom ="Mortendi";
$mortendi->cours="1.76";
$mortendi->info();
?>