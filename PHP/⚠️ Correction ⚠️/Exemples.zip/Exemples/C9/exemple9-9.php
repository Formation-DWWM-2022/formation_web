<?php
class action 
{
  private $propnom;
  private $propcours;
  protected $propbourse;
  function __construct($nom,$cours,$bourse="Paris")
  {
	  $this->propnom=$nom;
	  $this->propcours=$cours;
    $this->propbourse=$bourse;
  }
  function __destruct() 
  {
    echo "L'action $this->propnom n'existe plus!<br />";
  }
}
//CrÈation d'objets
$alcotel = new action("Alcotel",10.21);
$bouch = new action("Bouch",9.11,"New York");
$bim = new action("BIM",34.50,"New York");
$ref=&$bim;
var_dump($alcotel);
echo "<hr />";
unset($alcotel);
unset($bim);
echo "<hr /><h4> FIN du script </h4><hr />";
?>
