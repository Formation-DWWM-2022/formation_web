<?php
class action

{
  public $nom;
  function __construct($nom)
  {
    $this->nom=$nom;
  }
  function __destruct()
  {
    echo "L'action $this->nom n'existe plus!<br />";
  }
  function __clone()
  {
    $this->nom="Clone de ".$this->nom;
  }
}
//Création d'objets
$alcotel = new action("Alcotel",99);
$clone= clone $alcotel;
$bim=$alcotel;
$ref=&$bim;
//Modification d'une propriété
$bim->nom="BIM";
echo $ref->nom ,"<hr />";
echo $alcotel->nom ,"<hr />";
//Affichage des caractéristiques des objets
echo "alcotel =",print_r($alcotel),"<br />";
echo "bim =",print_r($bim),"<br />";
echo "ref =",print_r($ref),"<br />";
echo "clone =",print_r($clone),"<br />";
//Suppression des objets
unset($clone);
unset($alcotel);
unset($bim);
unset($ref);
?>
