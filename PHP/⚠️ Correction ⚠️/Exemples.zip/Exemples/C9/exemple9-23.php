<?php
require 'exemple9-21.php';
require 'exemple9-22.php';
//Objet Action
use Bourse\Action ;
$action = new Action\Valeur("Dexia",4.56);
$action->info();
$action->changeCours(4.72);
$action->info();
//Objet Obligation
use Bourse\Obligation;
$oblig = new Obligation\Valeur("EdF",55,3.8);
$oblig->info();
$oblig->changeCours(56);
$oblig->info();
?>
