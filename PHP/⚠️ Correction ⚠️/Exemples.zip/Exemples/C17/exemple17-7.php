<!DOCTYPE html>
<html lang="fr">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
  <title>Recherche de client</title>
  <style type="text/css" >
    div{font-size: 20px;}
  </style>
 </head>
 <body>
<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">

  <fieldset>
    <legend>Recherche de client par département</legend>
    <label>Département</label><input type="number"  name="departement" /><br />   <!-- 1 -->
    <input type="submit" value="Envoyer" />
  </fieldset>
</form>
 </body>
</html>
<?php
if( isset($_POST['departement']))
{
  $dep=$_POST['departement'];   //2
  $objdb = new SQLite3('sportifs.db'); //3
  $objstmt=$objdb->prepare("SELECT id_personne,nom,prenom FROM personne WHERE  depart= :dep ");    //4
  //*****Liaison du paramètre
  $objstmt->bindParam(':dep',$dep,SQLITE3_INTEGER);  //5
  $result=$objstmt->execute(); //6
  //*****Affichage
  echo "<div><h3>Client(s) dans le département $dep</h3><hr />";
  while($ligne=$result->fetchArray())//7
  {
    echo "<h3> ID: ", $ligne[0]," &nbsp; ",$ligne[1]," &nbsp; ",$ligne[2],"</h3>";
  }
  $result->finalize();   //8
  $objdb->close(); //9
  echo "</div>";
}
?>
