<!DOCTYPE html>
<html lang="fr">
 <head>
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
  <title>Saisissez vos coordonnées</title>
 </head>
 <body>
<form action= "<?php echo $_SERVER['PHP_SELF'];?>" method="post"
enctype="application/x-www-form-urlencoded">
<fieldset>
<legend><b>Vos coordonnées</b></legend>
<table>
<tr><td>Nom : </td><td><input type="text" name="nom" size="40" maxlength="30"/></td></tr>
<tr><td>Prénom : </td><td><input type="text" name="prenom" size="40" maxlength="30"/></td></tr>
<tr><td>Département : </td><td><input type="number" step="1" name="depart" /></td></tr>
<tr><td>Mail : </td><td><input type="email" name="mail" size="40" maxlength="50"/></td></tr>
<tr>
<td><input type="reset" value=" Effacer "></td>
<td><input type="submit" value=" Envoyer "></td>
</tr>
</table>
</fieldset>
</form>
<?php
if(!empty($_POST['nom'])&& !empty($_POST['depart']) && !empty($_POST['mail']))
{
 $objdb=new SQLite3("sportifs.db");
 $nom= $objdb->escapeString($_POST['nom']);
 $prenom= $objdb->escapeString($_POST['prenom']);
 $depart= $objdb->escapeString($_POST['depart']);
 $mail= $objdb->escapeString($_POST['mail']);
 //Requète SQL
 $requete="INSERT INTO personne  VALUES(NULL,'$nom','$prenom','$depart','$mail')";
 $result=$objdb->exec($requete);
 if(!$result)
  {
    echo "<h2>Erreur d'insertion \n n°",$objdb->lastErrorCode(),"</h2>";
  }
  else
  {
    echo "<script type=\"text/javascript\">
    alert('Vous êtes enregistré Votre numéro de client est : ". $objdb->lastInsertRowId()."')</script>";
  }
  $objdb->close() ;
}
else {echo "Formulaire à compléter!";}
?>
</body>
</html>
