<?php
$tab=range(1,20);
print_r($tab);
for($i=1;$i<9;$i++)
{
  echo rand(1,20),"..";
}
?>