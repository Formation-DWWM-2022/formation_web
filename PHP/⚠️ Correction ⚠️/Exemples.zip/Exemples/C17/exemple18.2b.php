<?php
if ($id_base = sqlite_open('C:/wamp/apps/sqlitemanager/sportifstest', 0666,$erreur))
{
  echo "La base sportifs est ouverte";
  //*****************************
  //Création de la table personne
  $req_personne="CREATE TABLE personne (
  id_personne INTEGER PRIMARY KEY  ,
  nom VARCHAR( 20 )  NOT NULL ,
  prenom VARCHAR( 20 ) ,
  depart INTEGER( 2) NOT NULL,
  mail VARCHAR(50) NOT NULL)";
  if( sqlite_exec($id_base,$req_personne)) echo "La table personne est créée";
  //**************************************
  //création de la table sport
  $req_sport="CREATE TABLE sport(id_sport INTEGER PRIMARY KEY ,design VARCHAR( 30 ) UNIQUE NOT NULL)";
  //CREATE UNIQUE INDEX sport_design ON sport(design);
  if(sqlite_exec($id_base,$req_sport))echo "La table sport est créée";
  //*****************************
  //création de la table pratique
  $req_pratique="CREATE TABLE pratique (
  id_personne INTEGER  NOT NULL,
  id_sport INTEGER  NOT NULL ,
  niveau TINYINT,
  PRIMARY KEY (id_personne,id_sport));
  CREATE INDEX cle ON pratique(id_personne,id_sport);";
  if( sqlite_exec($id_base,$req_pratique)) echo "La table pratique est créée";
  sqlite_close($id_base) ;
}
else
{
  echo "ERREUR : $erreur";
}
?>
