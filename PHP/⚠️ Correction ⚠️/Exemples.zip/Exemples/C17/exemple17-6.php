<?php
function presentation($mot)//1
{
  return ucfirst(strtolower($mot));
}

if ($objdb=new SQLite3("sportifs.db",SQLITE3_OPEN_READONLY))
{
  $objdb->createFunction('initiale','presentation');//2
  $requete = "SELECT initiale(nom) AS nom, initiale(prenom) AS prenom,lower(mail) AS mail FROM personne" ;
  if ($result = $objdb->query($requete))  //3
  {
   echo "<h3>Liste des personnes enregistrées</h3>";
    while($ligne=$result->fetchArray(SQLITE3_BOTH))
    {

     echo $ligne[0]," &nbsp; &nbsp;", $ligne[1] , "&nbsp; : &nbsp;&nbsp;&nbsp;", $ligne[2],"<br />";  //4
     //echo $ligne['nom'] ," &nbsp; &nbsp;", $ligne['prenom'], " &nbsp; : &nbsp;&nbsp;&nbsp;", $ligne['mail'] ,"<br />";//5
    }
  }
  else echo " La requête n'a pas aboutie" ;
  $objdb->close();
}
else echo $erreur ;
?>
