<?php
if ($db=new PDO("sqlite:sportifs.db",SQLITE3_OPEN_READONLY))
{
  $requete = "SELECT id_personne as 'Numéro', nom as 'Nom', prenom as 'Prénom', mail FROM personne" ;
  if ($result=$db->query($requete))
  {
   unset($db);
   //Lecture des résultats
   echo "<h3>Personnes enregistrées </h3>";
   while($tab=$result->fetch(PDO::FETCH_ASSOC))
   {
     foreach($tab as $cle=>$valeur)
     {
       echo $cle," : &nbsp;&nbsp;",$valeur," &nbsp; ";
     }
     echo "<br />";
    }
  }
  else echo " La requête n'a pas aboutie" ;
}
else echo "ERREUR",$db->ErrorInfo() ;
?>
