<?php
$objdb=new SQLite3("sportifs.db");
$requete = "SELECT * FROM personne" ;
if($result=$objdb->query($requete))
{
  echo " La requête est réalisée";
//Lecture des résultats
var_dump($result);
}
else
{
  echo "Erreur n° :",$objdb->lastErrorCode(),"...",$objdb->lastErrorMsg() ;
}
$objdb->close();
?>
