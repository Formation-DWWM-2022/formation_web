<?php
if ($objdb=new SQLite3("sportifs.db",SQLITE3_OPEN_READONLY) )
{
  $requete = "SELECT nom,prenom FROM personne" ;
  if ($result = $objdb->query ($requete))
  {
    echo "<h3>Liste des personnes enregistrées</h3>";
    
    while($ligne=$result->fetchArray(SQLITE3_ASSOC))
    {
      echo "Nom : <b>{$ligne["nom"]}</b> &nbsp;";
      echo "Prénom : <b>{$ligne["prenom"]} </b><br />";
    }
  }
  else echo " La requête n'a pas aboutie" ;
  $objdb->close();
}
else echo $objdb->lastErrorCode() ;
?>
