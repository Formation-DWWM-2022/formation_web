<?php
if($db = new SQLite3('sportifs.db'))
{
  //$requete = "SELECT nom,prenom FROM personne" ;

  $result = $db->query('SELECT * FROM personne');

while($ligne=$result->fetchArray())
{

   var_dump($ligne);

}
 }


?>