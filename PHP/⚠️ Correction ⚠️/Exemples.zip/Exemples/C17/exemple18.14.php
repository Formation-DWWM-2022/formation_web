<?php
$db=new SQLite3("sportifs.db");
$db->close();
$db->open('sportifs.db') ;
  $requete = "SELECT * FROM personne" ;
  $result=$db->querySingle($requete, TRUE);
   print_r($result);
  //$result = $db->query('SELECT * FROM personne');
/*
while($ligne=$result->fetchArray())
{

   var_dump($ligne);

}


/*

  for($i=0;$i<count($result);$i++)
    {
      echo "Ligne $i : &nbsp;";
      foreach($result[$i] as $cle=>$valeur)
      {
       echo $cle," : &nbsp;",$valeur,"...&nbsp;";
      }
      echo "<br />";
    }
}
  else echo " La requête n'a pas aboutie" ;
else echo $erreur ;

*/
?>