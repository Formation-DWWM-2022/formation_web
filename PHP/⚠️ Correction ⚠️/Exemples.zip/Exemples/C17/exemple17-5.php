 <!DOCTYPE html>
<html lang="fr">
 <head>
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
  <title>Lecture des personnes enregistrées</title>
  <style>
  table,td,th  {border:   2px solid  red;; font-size: larger ;}

  </style>
 </head>
 <body>





<?php
if ($objdb=new SQLite3("sportifs.db",SQLITE3_OPEN_READONLY) )
{
  $requete = "SELECT * FROM personne" ; //1
  if ($result = $objdb->query ($requete))  //2
  {
    echo "<h3>Liste des personnes enregistrées</h3>";
    echo "<table><thead><tr>";
    $nbcol=$result->numColumns();  //3
   // echo "Il y a ",$nbcol,"col<br />";
    for($i=0;$i<$nbcol;$i++)  //4
    {
       echo "<th>",$result->columnName($i),"</th>";    //5
    }
    echo "</tr></thead><tbody>" ;
    while($ligne=$result->fetchArray(SQLITE3_NUM))  //6
    {
     echo "<tr>";
     for($i=0;$i<$nbcol;$i++) //7
     {
          echo "<td>{$ligne[$i]}&nbsp;</td>";   //8
     }
     echo "</tr>";
    }
    echo "</tbody></table>" ;
    $result->finalize();   //9
  }
  else echo " La requête n'a pas aboutie" ;
  $objdb->close();
}
else echo $objdb->lastErrorCode() ;
?>

</body>
</html>