<?php
if ($objdb = new SQLite3('sportifs.db'))
{
  echo "La base sportifs est ouverte <br />";
  //*****************************
  //Création de la table personne
  $req_personne="CREATE TABLE IF NOT EXISTS personne (
  id_personne INTEGER PRIMARY KEY AUTOINCREMENT ,
  nom VARCHAR( 20 )  NOT NULL ,
  prenom VARCHAR( 20 ) ,
  depart INTEGER( 2) NOT NULL,
  mail VARCHAR(50) NOT NULL)";
  if( $objdb->exec($req_personne)) echo "La table personne est créée<br />";//1
  else{echo $objdb->lastErrorMsg();}//2
  //**************************************
  //création de la table sport

  $req_sport="CREATE TABLE IF NOT EXISTS sport(
  id_sport INTEGER PRIMARY KEY AUTOINCREMENT,
  design VARCHAR( 30 ) UNIQUE NOT NULL)";
  if($objdb->exec($req_sport))echo "La table sport est créée<br />";//3
  else{echo $objdb->lastErrorMsg();}//4
  //*****************************
  //création de la table pratique
  $req_pratique="CREATE TABLE IF NOT EXISTS pratique (
  id_personne INTEGER  NOT NULL,
  id_sport INTEGER  NOT NULL ,
  niveau TINYINT,
  PRIMARY KEY (id_personne,id_sport))";
  if($objdb->exec($req_pratique)) echo "La table pratique est créée<br />"; //5
  else{echo $objdb->lastErrorMsg();}//6

  $objdb->close() ;
}
else
{
  echo "ERREUR de connexion";
}
?>