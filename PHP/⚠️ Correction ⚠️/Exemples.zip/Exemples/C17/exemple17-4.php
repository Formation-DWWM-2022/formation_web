<?php
if ($objdb=new SQLite3("sportifs.db") )
{
  $requete1="BEGIN TRANSACTION trans;";
   $objdb->exec($requete1);
  $requete2="INSERT  INTO personnes(id_personne,nom,prenom,depart,mail) VALUES (NULL,'Spencer','Marc','75','marc@spen.org');";
  $test1= $objdb->exec($requete2);
  echo "test1= ",$test1,"<br />"  ;

  $requete3="INSERT INTO pratique(id_personne,id_sport,niveau) VALUES(last_insert_rowid(),2,3);";
  $test2= $objdb->exec($requete3);
   echo "test2= ",$test2,"<br />"  ;

  if($test1 and $test2 )
  {
    $requete4="COMMIT TRANSACTION trans";
    $objdb->exec($requete4);
    echo "<br />Les requètes ont été exécutées<hr />";
  }
  else
  {
    $requete5="ROLLBACK TRANSACTION trans";
    $objdb->exec($requete5);
    echo "<br />Les requètes n'ont pas été exécutées<hr />";
  }
    $objdb->close() ;
}
else
{
  echo "ERREUR !";
}
?>
