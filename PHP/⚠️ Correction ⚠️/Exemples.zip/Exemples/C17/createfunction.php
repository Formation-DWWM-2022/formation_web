<?php
function presentation($mot)
{
  return ucfirst(strtolower($mot));
}

if ($objdb=new SQLite3("sportifs.db",SQLITE3_OPEN_READONLY))
{
  $objdb->createFunction('initiale','presentation');
  $requete = "SELECT upper(nom) AS nom, initiale(prenom) AS prenom,lower(mail) AS mail FROM personne" ;
  if ($result = $objdb->query($requete))
  {
   echo "<h3>Liste des personnes enregistrées</h3>";
    while($ligne=$result->fetchArray(SQLITE3_BOTH))
    {

     echo $ligne[0]," &nbsp; &nbsp;", $ligne[1] , "&nbsp; : &nbsp;&nbsp;&nbsp;", $ligne[2],"<br />";
     echo $ligne['nom'] ," &nbsp; &nbsp;", $ligne['prenom'], " &nbsp; : &nbsp;&nbsp;&nbsp;", $ligne['mail'] ,"<br />";
    }


  }
  else echo " La requête n'a pas aboutie" ;
  $objdb->close();
}
else echo $erreur ;
?>
