<?php
header ("Content-type: image/png");
$idimg=imagecreate(800,400);
$fond=imagecolorallocate($idimg,255,255,51);
$noir=imagecolorallocate($idimg,0,0,0);
//Définition de l'épaisseur de trait de 2 pixels
imagesetthickness($idimg,2) ;
//Tracé des droites
for($x=0;$x<800;$x+=10)
{
  imageline($idimg,400,399,$x,0,$noir);
}
imagepng($idimg,"rayons.png");
imagepng($idimg);
imagedestroy($idimg);
?>
