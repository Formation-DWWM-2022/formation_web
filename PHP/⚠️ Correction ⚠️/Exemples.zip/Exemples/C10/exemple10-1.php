<?php
header ("Content-type: image/png"); 
//Création du cadre 800x400 pixels
$idimg=imagecreate(800,400);
//Création des couleurs
$fond=imagecolorallocate($idimg,255,255,51); $noir=imagecolorallocate($idimg,0,0,0); 
//******************
//TRACÉS DES FORMES
//******************
//Enregistrement de l'image dans un fichier
imagepng($idimg,"monimage.png");
//Envoi de l'image au navigateur
imagepng($idimg);   
//Libération de l'espace mémoire
imagedestroy($idimg);
?>