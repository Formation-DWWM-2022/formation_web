<?php
$img=imagecreatefrompng("sinus.png");
$tabcoup = array('x' =>0, 'y' =>0, 'width' =>315, 'height'=>400); $coupe=imagecrop($img,$tabcoup);
imageflip($coupe,IMG_FLIP_VERTICAL);
imagepng($coupe,"test.png");
?>
<img src="test.png" />
