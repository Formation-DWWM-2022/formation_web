<!DOCTYPE html> 
<html lang="fr">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" /> 
<title>Histogramme dynamique</title>
</head> 
<body> 
<div>
 <h2>Résultats des ventes de la semaine</h2> 
 <?php
// Utilisation de la fonction 
include("exemple10-9.php");
$donn= array(850,2500,4050,2730,2075,2590,1450);
$texte = array("Lun","Mar","Mer","Jeu","Ven","Sam","Dim");
$titre = "Ventes hebdomadaires PHP 7";
histo(700,450,$donn,$texte,$titre);
?>
<img src="histo.png" alt="Ventes" />
</div>
</body>
</html>