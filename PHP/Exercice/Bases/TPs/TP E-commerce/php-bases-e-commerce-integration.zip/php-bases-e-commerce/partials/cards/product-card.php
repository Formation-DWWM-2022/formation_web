<div class="product-card">
    <div class="card-img"></div>
    <div class="card-content">
        <h2 class="product-title">Product name</h2>
        <div class="product-details">
            <a href="details.php">Plus de détails</a>
            <div class="product-price">99.99<span class="currency">€</span></div>
        </div>
    </div>
</div>