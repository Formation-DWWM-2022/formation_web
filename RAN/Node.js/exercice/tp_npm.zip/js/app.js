/*
import Swal from '../node_modules/sweetalert2/src/sweetalert2.js'

document.querySelector('.btn.btn-success').addEventListener('click', () => {
    Swal.fire({
        title: 'Error!',
        text: 'Do you want to continue',
        icon: 'error',
        confirmButtonText: 'Cool'
    })
});
*/
