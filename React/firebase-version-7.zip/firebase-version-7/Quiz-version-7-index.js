import React from 'react'

const Quiz = () => {
  return (
    <div>Quiz</div>
  )
}

export default Quiz